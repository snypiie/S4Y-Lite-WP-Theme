<?php
/*
	Theme Name:  Sahu4You Lite
	Description: Custom child theme for the <a href="http://sahu4you.com">Genesis Child Thmes</a>.
	Author:       Vikas Sahu
	Author URI:  https://www.sahu4you.com
	Version:     1.0.0
	License:     GPL-2.0+
	License URI: http://www.gnu.org/licenses/gpl-2.0.html
	Template:    genesis
*/


echo '<section class="no-results not-found">';

	echo '<header class="entry-header"><h1 class="entry-title">' . esc_html__( 'Nothing Found', 'ea_genesis_child' ) . '</h1></header>';
	echo '<div class="entry-content">';

	if ( is_search() ) {

		echo '<p>' . esc_html__( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'ea_genesis_child' ) . '</p>';
		get_search_form();

	} else {

		echo '<p>' . esc_html__( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'ea_genesis_child' ) . '</p>';
		get_search_form();
	}

	echo '</div>';
echo '</section>';
